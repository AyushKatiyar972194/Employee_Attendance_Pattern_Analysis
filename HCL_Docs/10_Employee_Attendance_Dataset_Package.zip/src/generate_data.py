from __future__ import annotations

import csv
import random
import sqlite3
from datetime import date, datetime, timedelta
from pathlib import Path

import pandas as pd

SEED = 42
random.seed(SEED)

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

PROJECT_NAME = "employee_attendance_pattern_analysis"
EXCEL_PATH = DATA_DIR / f"{PROJECT_NAME}_data.xlsx"
DB_PATH = DATA_DIR / "app.db"
REPORT_PATH = DATA_DIR / "validation_report.xlsx"
REPORT_TXT = DATA_DIR / "validation_report.txt"

# Fictional Indian names and locations. These are synthetic demo identities.
FIRST_NAMES = [
    "Aarav", "Vivaan", "Aditya", "Vihaan", "Arjun", "Reyansh", "Krishna", "Ishaan",
    "Ananya", "Diya", "Aadhya", "Saanvi", "Myra", "Ira", "Kavya", "Meera",
    "Rohan", "Kabir", "Aanya", "Ishita", "Dev", "Nisha", "Rahul", "Priya",
    "Neha", "Kunal", "Tanvi", "Manav", "Ritika", "Siddharth"
]
LAST_NAMES = [
    "Sharma", "Verma", "Gupta", "Singh", "Katiyar", "Mishra", "Yadav", "Agarwal",
    "Chauhan", "Srivastava", "Jain", "Kapoor", "Rao", "Nair", "Mehta", "Das",
    "Malhotra", "Bansal", "Saxena", "Tiwari", "Khan", "Patel", "Joshi", "Sethi"
]
INDIAN_OFFICE_LOCATIONS = ["Noida Sector 62", "Noida Sector 16", "Ghaziabad Raj Nagar", "Lucknow Gomti Nagar", "Delhi Okhla"]
DEPARTMENTS = ["Engineering", "Human Resources", "Finance", "Sales", "Customer Support"]
STATUSES = [
    ("PRESENT", "Present", 1, 0, 0, 1),
    ("ABSENT", "Absent", 0, 1, 0, 1),
    ("APPROVED_LEAVE", "Approved Leave", 0, 0, 1, 1),
    ("HOLIDAY", "Holiday", 0, 0, 0, 1),
]

def iso(dt):
    return dt.isoformat(sep=" ", timespec="seconds")

def make_schema(conn: sqlite3.Connection):
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.executescript("""
    DROP VIEW IF EXISTS vw_attendance_analysis;
    DROP TABLE IF EXISTS attendance_records;
    DROP TABLE IF EXISTS work_calendar;
    DROP TABLE IF EXISTS attendance_statuses;
    DROP TABLE IF EXISTS employees;
    DROP TABLE IF EXISTS departments;

    CREATE TABLE departments (
        department_id INTEGER PRIMARY KEY CHECK (department_id > 0),
        department_name TEXT NOT NULL UNIQUE CHECK (length(trim(department_name)) > 0),
        location TEXT NOT NULL CHECK (length(trim(location)) > 0),
        is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
        created_at TEXT NOT NULL
    );

    CREATE TABLE employees (
        employee_id INTEGER PRIMARY KEY CHECK (employee_id > 0),
        employee_code TEXT NOT NULL UNIQUE CHECK (length(trim(employee_code)) > 0),
        department_id INTEGER NOT NULL,
        hire_date TEXT NOT NULL,
        employment_status TEXT NOT NULL CHECK (employment_status IN ('ACTIVE', 'INACTIVE')),
        is_active INTEGER NOT NULL CHECK (is_active IN (0, 1)),
        created_at TEXT NOT NULL,
        UNIQUE (employee_id, department_id),
        FOREIGN KEY (department_id) REFERENCES departments(department_id),
        CHECK ((employment_status = 'ACTIVE' AND is_active = 1) OR
               (employment_status = 'INACTIVE' AND is_active = 0))
    );

    CREATE TABLE attendance_statuses (
        status_code TEXT PRIMARY KEY CHECK (
            status_code IN ('PRESENT', 'ABSENT', 'APPROVED_LEAVE', 'HOLIDAY')
        ),
        status_name TEXT NOT NULL UNIQUE,
        counts_as_present INTEGER NOT NULL CHECK (counts_as_present IN (0, 1)),
        counts_as_absence INTEGER NOT NULL CHECK (counts_as_absence IN (0, 1)),
        is_leave INTEGER NOT NULL CHECK (is_leave IN (0, 1)),
        is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1))
    );

    CREATE TABLE work_calendar (
        calendar_date TEXT NOT NULL,
        department_id INTEGER NOT NULL,
        is_working_day INTEGER NOT NULL CHECK (is_working_day IN (0, 1)),
        scheduled_start_time TEXT,
        scheduled_end_time TEXT,
        grace_minutes INTEGER NOT NULL DEFAULT 10 CHECK (grace_minutes BETWEEN 0 AND 120),
        day_type TEXT NOT NULL CHECK (day_type IN ('WORKING', 'WEEKLY_OFF', 'HOLIDAY', 'SPECIAL')),
        calendar_note TEXT,
        PRIMARY KEY (calendar_date, department_id),
        FOREIGN KEY (department_id) REFERENCES departments(department_id),
        CHECK (
          (is_working_day = 1 AND day_type IN ('WORKING', 'SPECIAL')
           AND scheduled_start_time IS NOT NULL AND scheduled_end_time IS NOT NULL)
          OR
          (is_working_day = 0 AND day_type IN ('WEEKLY_OFF', 'HOLIDAY'))
        )
    );

    CREATE TABLE attendance_records (
        attendance_id INTEGER PRIMARY KEY CHECK (attendance_id > 0),
        employee_id INTEGER NOT NULL,
        department_id INTEGER NOT NULL,
        attendance_date TEXT NOT NULL,
        status_code TEXT NOT NULL,
        check_in_time TEXT,
        check_out_time TEXT,
        source_label TEXT NOT NULL CHECK (source_label IN ('SYNTHETIC_IMPORT', 'SYNTHETIC_MANUAL')),
        record_note TEXT,
        created_at TEXT NOT NULL,
        UNIQUE (employee_id, attendance_date),
        FOREIGN KEY (employee_id, department_id)
          REFERENCES employees(employee_id, department_id),
        FOREIGN KEY (attendance_date, department_id)
          REFERENCES work_calendar(calendar_date, department_id),
        FOREIGN KEY (status_code) REFERENCES attendance_statuses(status_code),
        CHECK (check_in_time IS NULL OR length(check_in_time) = 5),
        CHECK (check_out_time IS NULL OR length(check_out_time) = 5),
        CHECK (check_in_time IS NULL OR check_out_time IS NULL OR check_out_time >= check_in_time),
        CHECK (
          (status_code = 'PRESENT' AND check_in_time IS NOT NULL)
          OR status_code IN ('ABSENT', 'APPROVED_LEAVE', 'HOLIDAY')
        )
    );

    CREATE VIEW vw_attendance_analysis AS
    SELECT
        ar.attendance_id,
        e.employee_code,
        e.employee_id,
        e.hire_date,
        e.employment_status,
        e.is_active AS employee_is_active,
        d.department_id,
        d.department_name,
        d.location,
        d.is_active AS department_is_active,
        ar.attendance_date,
        strftime('%Y', ar.attendance_date) AS attendance_year,
        strftime('%m', ar.attendance_date) AS attendance_month,
        strftime('%Y-%m', ar.attendance_date) AS attendance_year_month,
        strftime('%w', ar.attendance_date) AS weekday_number,
        CASE strftime('%w', ar.attendance_date)
          WHEN '0' THEN 'Sunday' WHEN '1' THEN 'Monday'
          WHEN '2' THEN 'Tuesday' WHEN '3' THEN 'Wednesday'
          WHEN '4' THEN 'Thursday' WHEN '5' THEN 'Friday'
          WHEN '6' THEN 'Saturday' END AS weekday_name,
        wc.is_working_day,
        wc.day_type,
        wc.scheduled_start_time,
        wc.scheduled_end_time,
        wc.grace_minutes,
        ar.status_code,
        s.status_name,
        s.counts_as_present,
        s.counts_as_absence,
        s.is_leave,
        ar.check_in_time,
        ar.check_out_time,
        CASE WHEN ar.check_in_time IS NOT NULL
          THEN (CAST(substr(ar.check_in_time,1,2) AS INTEGER) * 60
              + CAST(substr(ar.check_in_time,4,2) AS INTEGER))
             - (CAST(substr(wc.scheduled_start_time,1,2) AS INTEGER) * 60
              + CAST(substr(wc.scheduled_start_time,4,2) AS INTEGER))
          ELSE NULL END AS arrival_delay_minutes,
        CASE WHEN ar.check_in_time IS NOT NULL AND wc.scheduled_start_time IS NOT NULL
          AND (CAST(substr(ar.check_in_time,1,2) AS INTEGER) * 60
             + CAST(substr(ar.check_in_time,4,2) AS INTEGER))
            > (CAST(substr(wc.scheduled_start_time,1,2) AS INTEGER) * 60
             + CAST(substr(wc.scheduled_start_time,4,2) AS INTEGER))
             + wc.grace_minutes THEN 1 ELSE 0 END AS is_late,
        CASE WHEN ar.check_in_time IS NOT NULL AND ar.check_out_time IS NOT NULL
          THEN (CAST(substr(ar.check_out_time,1,2) AS INTEGER) * 60
              + CAST(substr(ar.check_out_time,4,2) AS INTEGER))
             - (CAST(substr(ar.check_in_time,1,2) AS INTEGER) * 60
              + CAST(substr(ar.check_in_time,4,2) AS INTEGER))
          ELSE NULL END AS elapsed_duration_minutes,
        ar.source_label,
        ar.record_note,
        ar.created_at
    FROM attendance_records ar
    JOIN employees e ON e.employee_id = ar.employee_id
                    AND e.department_id = ar.department_id
    JOIN departments d ON d.department_id = ar.department_id
    JOIN work_calendar wc ON wc.calendar_date = ar.attendance_date
                         AND wc.department_id = ar.department_id
    JOIN attendance_statuses s ON s.status_code = ar.status_code;
    """)

def generate_rows():
    now = datetime(2026, 11, 18, 9, 0, 0)
    departments = []
    for i, name in enumerate(DEPARTMENTS, 1):
        departments.append({
            "department_id": i,
            "department_name": name,
            "location": INDIAN_OFFICE_LOCATIONS[(i - 1) % len(INDIAN_OFFICE_LOCATIONS)],
            "is_active": 1,
            "created_at": iso(now)
        })

    # 50 synthetic employees, 10 per department.
    employees = []
    used_names = set()
    for emp_id in range(1, 51):
        dept_id = ((emp_id - 1) // 10) + 1
        while True:
            full_name = f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"
            if full_name not in used_names:
                used_names.add(full_name)
                break
        hire = date(2022 + (emp_id % 4), 1 + (emp_id % 12), 1 + (emp_id % 26))
        employees.append({
            "employee_id": emp_id,
            "employee_code": f"EMP{emp_id:04d}",
            "department_id": dept_id,
            "hire_date": hire.isoformat(),
            "employment_status": "ACTIVE",
            "is_active": 1,
            "created_at": iso(now),
            # Name is deliberately not a DB column; only appears in Excel as a synthetic label.
            "_display_name": full_name
        })

    statuses = [
        {"status_code": x[0], "status_name": x[1], "counts_as_present": x[2],
         "counts_as_absence": x[3], "is_leave": x[4], "is_active": x[5]}
        for x in STATUSES
    ]

    start = date(2026, 10, 1)
    dates = [start + timedelta(days=i) for i in range(30)]
    calendar = []
    for d in dates:
        is_weekday = d.weekday() < 5
        for dept in departments:
            calendar.append({
                "calendar_date": d.isoformat(),
                "department_id": dept["department_id"],
                "is_working_day": int(is_weekday),
                "scheduled_start_time": "09:00" if is_weekday else None,
                "scheduled_end_time": "18:00" if is_weekday else None,
                "grace_minutes": 10,
                "day_type": "WORKING" if is_weekday else "WEEKLY_OFF",
                "calendar_note": None if is_weekday else "Synthetic weekend"
            })

    # Six observation dates spanning three weeks. Exactly 50 x 6 = 300 facts.
    observation_dates = [
        date(2026, 10, 1), date(2026, 10, 5), date(2026, 10, 9),
        date(2026, 10, 13), date(2026, 10, 19), date(2026, 10, 23)
    ]
    facts = []
    attendance_id = 1
    for d in observation_dates:
        for emp in employees:
            dept_id = emp["department_id"]
            dept_name = DEPARTMENTS[dept_id - 1]

            # Pattern 1: Customer Support has higher late-arrival probability.
            late_probability = 0.43 if dept_name == "Customer Support" else 0.13
            # Pattern 2: Monday has a slightly higher absence probability.
            absence_probability = 0.10 if d.weekday() == 0 else 0.045
            # Approved leave remains a separate status and is not counted as absence.
            leave_probability = 0.035

            roll = random.random()
            if roll < absence_probability:
                status = "ABSENT"
                check_in = check_out = None
            elif roll < absence_probability + leave_probability:
                status = "APPROVED_LEAVE"
                check_in = check_out = None
            else:
                status = "PRESENT"
                # Pattern 3: HR has the most consistent start times; Engineering has lower lateness.
                if dept_name == "Human Resources":
                    late_probability_local = 0.06
                elif dept_name == "Customer Support":
                    late_probability_local = 0.48
                else:
                    late_probability_local = late_probability

                if random.random() < late_probability_local:
                    delay = random.randint(12, 38)
                    # A few plausible but extreme late-arrival observations.
                    if (emp["employee_id"], d.isoformat()) in [(7, "2026-10-13"), (38, "2026-10-19")]:
                        delay = 185
                    check_in_min = 9 * 60 + delay
                else:
                    check_in_min = 8 * 60 + random.randint(48, 59)
                check_in = f"{check_in_min // 60:02d}:{check_in_min % 60:02d}"

                # Usual departure around 18:00; deliberately add a few long-duration outliers.
                duration = random.randint(465, 535)
                if (emp["employee_id"], d.isoformat()) in [(12, "2026-10-09"), (44, "2026-10-23")]:
                    duration = 840
                check_out_min = min(check_in_min + duration, 23 * 60 + 59)
                check_out = f"{check_out_min // 60:02d}:{check_out_min % 60:02d}"

            # 2.33% missing values: 7 optional checkout times among present records.
            if status == "PRESENT" and attendance_id in {11, 42, 83, 127, 166, 221, 278}:
                check_out = None

            note = None
            if status == "ABSENT":
                note = "Synthetic absence example"
            elif status == "APPROVED_LEAVE":
                note = "Synthetic approved leave example"
            elif attendance_id in {11, 42, 83, 127, 166, 221, 278}:
                note = "Checkout missing in source sample"

            facts.append({
                "attendance_id": attendance_id,
                "employee_id": emp["employee_id"],
                "department_id": dept_id,
                "attendance_date": d.isoformat(),
                "status_code": status,
                "check_in_time": check_in,
                "check_out_time": check_out,
                "source_label": "SYNTHETIC_IMPORT" if attendance_id % 3 else "SYNTHETIC_MANUAL",
                "record_note": note,
                "created_at": iso(now + timedelta(seconds=attendance_id))
            })
            attendance_id += 1

    return departments, employees, statuses, calendar, facts, observation_dates

def insert_rows(conn, table, rows, columns):
    placeholders = ",".join(["?"] * len(columns))
    col_sql = ",".join(columns)
    values = [[row.get(c) for c in columns] for row in rows]
    conn.executemany(f"INSERT INTO {table} ({col_sql}) VALUES ({placeholders})", values)

def validate(conn, tables, duplicate_candidates):
    counts = {}
    for table in tables:
        counts[table] = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]

    fk_rows = conn.execute("PRAGMA foreign_key_check").fetchall()
    check_rows = []
    # Range/allowed-value checks
    check_rows.append(("department_count", counts["departments"], 5, counts["departments"] == 5))
    check_rows.append(("employee_count", counts["employees"], 50, counts["employees"] == 50))
    check_rows.append(("calendar_rows", counts["work_calendar"], 150, counts["work_calendar"] == 150))
    check_rows.append(("attendance_rows", counts["attendance_records"], "150-300", 150 <= counts["attendance_records"] <= 300))
    check_rows.append(("grace_minutes_range", conn.execute("SELECT COUNT(*) FROM work_calendar WHERE grace_minutes NOT BETWEEN 0 AND 120").fetchone()[0], 0, True))
    check_rows.append(("status_allowed_values", conn.execute("SELECT COUNT(*) FROM attendance_records WHERE status_code NOT IN ('PRESENT','ABSENT','APPROVED_LEAVE','HOLIDAY')").fetchone()[0], 0, True))
    check_rows.append(("invalid_clock_shape", conn.execute("""
        SELECT COUNT(*) FROM attendance_records
        WHERE (check_in_time IS NOT NULL AND (length(check_in_time) != 5 OR substr(check_in_time,3,1) != ':'))
           OR (check_out_time IS NOT NULL AND (length(check_out_time) != 5 OR substr(check_out_time,3,1) != ':'))
    """).fetchone()[0], 0, True))
    check_rows.append(("duplicate_employee_date_keys", conn.execute("""
        SELECT COUNT(*) FROM (
          SELECT employee_id, attendance_date, COUNT(*) c
          FROM attendance_records GROUP BY employee_id, attendance_date HAVING c > 1
        )
    """).fetchone()[0], 0, True))
    check_rows.append(("foreign_key_violations", len(fk_rows), 0, len(fk_rows) == 0))
    check_rows.append(("joined_view_columns", len([x[1] for x in conn.execute("PRAGMA table_info(vw_attendance_analysis)").fetchall()]), "30-40", 30 <= len(conn.execute("PRAGMA table_info(vw_attendance_analysis)").fetchall()) <= 40))
    check_rows.append(("duplicate_candidates_rejected", duplicate_candidates, 3, duplicate_candidates == 3))

    missing_checkout = conn.execute("""
        SELECT COUNT(*) FROM attendance_records
        WHERE status_code='PRESENT' AND check_out_time IS NULL
    """).fetchone()[0]
    total = counts["attendance_records"]
    check_rows.append(("missing_checkout_rate", missing_checkout, "2-3% of all records", 0.02 <= missing_checkout / total <= 0.03))

    return counts, fk_rows, check_rows

def main():
    departments, employees, statuses, calendar, facts, observation_dates = generate_rows()

    if DB_PATH.exists():
        DB_PATH.unlink()
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON;")
    make_schema(conn)

    insert_rows(conn, "departments", departments,
                ["department_id", "department_name", "location", "is_active", "created_at"])
    insert_rows(conn, "employees", employees,
                ["employee_id", "employee_code", "department_id", "hire_date", "employment_status", "is_active", "created_at"])
    insert_rows(conn, "attendance_statuses", statuses,
                ["status_code", "status_name", "counts_as_present", "counts_as_absence", "is_leave", "is_active"])
    insert_rows(conn, "work_calendar", calendar,
                ["calendar_date", "department_id", "is_working_day", "scheduled_start_time", "scheduled_end_time", "grace_minutes", "day_type", "calendar_note"])
    insert_rows(conn, "attendance_records", facts,
                ["attendance_id", "employee_id", "department_id", "attendance_date", "status_code", "check_in_time", "check_out_time", "source_label", "record_note", "created_at"])
    conn.commit()

    # Demonstrate 3 duplicate candidates: SQLite UNIQUE constraint rejects them.
    duplicate_candidates = 0
    for fact in facts[:3]:
        try:
            conn.execute("""
                INSERT INTO attendance_records
                (attendance_id, employee_id, department_id, attendance_date, status_code,
                 check_in_time, check_out_time, source_label, record_note, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                9000 + fact["attendance_id"], fact["employee_id"], fact["department_id"],
                fact["attendance_date"], fact["status_code"], fact["check_in_time"],
                fact["check_out_time"], fact["source_label"], "Duplicate candidate rejected",
                fact["created_at"]
            ))
            conn.commit()
        except sqlite3.IntegrityError:
            duplicate_candidates += 1
            conn.rollback()

    table_names = ["departments", "employees", "attendance_statuses", "work_calendar", "attendance_records"]
    counts, fk_rows, checks = validate(conn, table_names, duplicate_candidates)

    # Export exact table contents to CSV and Excel. Synthetic display names are a separate,
    # non-database annotation sheet and do not change the Step 8 schema.
    frames = {}
    for table in table_names:
        frames[table] = pd.read_sql_query(f"SELECT * FROM {table}", conn)

    employee_labels = pd.DataFrame([
        {"employee_code": e["employee_code"], "synthetic_display_name": e["_display_name"]}
        for e in employees
    ])

    for table, frame in frames.items():
        frame.to_csv(DATA_DIR / f"{table}.csv", index=False, encoding="utf-8-sig")

    with pd.ExcelWriter(EXCEL_PATH, engine="openpyxl") as writer:
        for table, frame in frames.items():
            frame.to_excel(writer, sheet_name=table[:31], index=False)
        employee_labels.to_excel(writer, sheet_name="Synthetic_Name_Key", index=False)

    # Validation report details
    count_rows = [{"check": "row_count", "item": t, "observed": counts[t], "expected": {
        "departments": "5", "employees": "50", "attendance_statuses": "4",
        "work_calendar": "150", "attendance_records": "150-300"
    }[t], "passed": True} for t in table_names]
    check_rows = [{"check": name, "observed": observed, "expected": expected, "passed": passed}
                  for name, observed, expected, passed in checks]

    patterns = [
        {"pattern_id": "PAT-01", "pattern": "Customer Support has a higher late-arrival probability than most other departments.", "where_to_check": "Compare is_late by department_name."},
        {"pattern_id": "PAT-02", "pattern": "Monday has a slightly higher absence probability than other weekdays.", "where_to_check": "Compare absence rate by weekday_name; interpret cautiously because only six observation dates are included."},
        {"pattern_id": "PAT-03", "pattern": "Human Resources has relatively consistent and punctual start times.", "where_to_check": "Compare late-arrival rate and arrival_delay_minutes by department_name."},
        {"pattern_id": "PAT-04", "pattern": "A small number of unusually long recorded durations and very late arrivals appear as outliers.", "where_to_check": "Inspect elapsed_duration_minutes and arrival_delay_minutes."},
        {"pattern_id": "PAT-05", "pattern": "Approved leave is a separate category and should not be combined with absence.", "where_to_check": "Compare status_name counts and status flags."},
    ]
    quality = [
        {"issue_id": "DQ-01", "issue": "Seven missing check_out_time values (nullable field), approximately 2.33% of 300 fact rows.", "handling": "Retain as missing; exclude from duration statistics and flag for review."},
        {"issue_id": "DQ-02", "issue": "Three duplicate employee/date candidate rows were attempted during generation.", "handling": "Rejected by UNIQUE(employee_id, attendance_date); not inserted into canonical CSV/DB tables."},
        {"issue_id": "DQ-03", "issue": "Two extreme late-arrival delays (185 minutes).", "handling": "Keep as valid-shaped but suspicious observations; flag and investigate, do not silently delete."},
        {"issue_id": "DQ-04", "issue": "Two unusually long elapsed recorded durations (840 minutes).", "handling": "Keep as outliers for data-quality analysis; confirm whether extended work or recording error."},
    ]

    with pd.ExcelWriter(REPORT_PATH, engine="openpyxl") as writer:
        pd.DataFrame(count_rows).to_excel(writer, sheet_name="Row_Counts", index=False)
        pd.DataFrame(check_rows).to_excel(writer, sheet_name="Validation_Checks", index=False)
        pd.DataFrame(patterns).to_excel(writer, sheet_name="Patterns_To_Find", index=False)
        pd.DataFrame(quality).to_excel(writer, sheet_name="Quality_Issues", index=False)

    with open(REPORT_TXT, "w", encoding="utf-8") as f:
        f.write("SYNTHETIC DATA VALIDATION REPORT\n")
        f.write(f"Random seed: {SEED}\n")
        f.write(f"Observation dates: {', '.join(d.isoformat() for d in observation_dates)}\n\n")
        f.write("ROW COUNTS\n")
        for table, count in counts.items():
            f.write(f"- {table}: {count}\n")
        f.write(f"\nForeign key check violations: {len(fk_rows)}\n")
        f.write(f"Duplicate candidates rejected by UNIQUE constraint: {duplicate_candidates}\n")
        f.write("\nCHECKS\n")
        for name, observed, expected, passed in checks:
            f.write(f"- {'PASS' if passed else 'FAIL'} | {name} | observed={observed} | expected={expected}\n")
        f.write("\nPATTERNS TO FIND\n")
        for p in patterns:
            f.write(f"- {p['pattern_id']}: {p['pattern']}\n")
        f.write("\nQUALITY ISSUES\n")
        for q in quality:
            f.write(f"- {q['issue_id']}: {q['issue']} Handling: {q['handling']}\n")

    # Export joined view as a convenience for manual inspection; not a base table.
    view_df = pd.read_sql_query("SELECT * FROM vw_attendance_analysis", conn)
    view_df.to_csv(DATA_DIR / "vw_attendance_analysis.csv", index=False, encoding="utf-8-sig")

    # Ensure foreign keys are still active on this connection and report.
    fk_enabled = conn.execute("PRAGMA foreign_keys").fetchone()[0]
    conn.close()

    failed = [c for c in checks if not c[3]]
    print("Synthetic dataset generation complete.")
    print(f"Database: {DB_PATH}")
    print(f"Excel: {EXCEL_PATH}")
    print(f"Validation report: {REPORT_PATH}")
    print(f"Foreign keys enabled during generation: {bool(fk_enabled)}")
    print(f"Row counts: {counts}")
    print(f"Joined view columns: {len(view_df.columns)}")
    print(f"Duplicate candidates rejected: {duplicate_candidates}")
    print(f"Validation checks failed: {len(failed)}")
    if failed:
        raise SystemExit(1)

if __name__ == "__main__":
    main()
